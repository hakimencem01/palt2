import sys
password = "abc123"


def login():
    loggedin = False
    attempt = 1
    while(not(loggedin)):
        if attempt > 5:
            print("You are blocked from loggin the system !")
            sys.exit()
        loginpass = input("Password : ")
        if loginpass == password:
            print("You have logged in !")
            loggedin = True
        else:
            attempt +=1

login()