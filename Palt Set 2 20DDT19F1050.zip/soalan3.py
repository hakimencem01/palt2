

file = open("emailaddress.txt","r")
filecopy =  open("emailaddress - Copy.txt","w")
newcontent = ""
insertattempt = 1
for eachline in file.readlines():
    perline = eachline.rstrip("\r\n")
    if insertattempt == 1:
      #  print(eachline)
        newcontent +=perline
    else:
  
        newcontent +=";"+perline
    insertattempt +=1

print(newcontent)
filecopy.write(newcontent)
filecopy.close()
file.close()