class Converter:
    def __init__(self,weight,unit):
        self.weight = int(weight)
        self.unit = unit
    def kg_to_pound(self):
        kg2pound_unit = 2.20462
        total = self.weight * kg2pound_unit
        print("Value : "+str(total)+" Pound")
    def pound_to_kg(self):
        pound2kg_unit = 0.45
        total = self.weight * pound2kg_unit
        print("Value : "+str(total)+" KG")
    def convert_auto(self):
        if self.unit.lower() == "kilogram":
            # if unit is kg, then convert to pound
            self.kg_to_pound()
        elif self.unit.lower() == "pound":
            # if unit is pound, then convert to kg
            self.pound_to_kg()
        else:
            print("unit undefined")

c = Converter(70,"Kilogram")
c.convert_auto()