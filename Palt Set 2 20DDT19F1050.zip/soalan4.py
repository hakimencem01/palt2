from tkinter import *
    
window = Tk() # 
window.title("Question 4") # set title
window.geometry("250x150")
window.config(padx=80,pady=100)
stateswap = True
def chgtext():
    global stateswap
    if stateswap:
        lbltext["text"] = "I have been changed"
        stateswap = False
    else:
        lbltext["text"] = "Change Text"
        stateswap = True
lbltext = Label(text="Changed Text")
btnChgText = Button(text="Change Text",command=chgtext)
lbltext.grid(row=4,column=1)
btnChgText.grid(row=3,column=1)
window.mainloop()